<?php
// Налаштування підключення до бази даних
$host = '150.238.148.25:23050';
$db = 'SunRiseShades';
$user = 'Denys';
$password = 'denyscivic';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Помилка підключення до бази даних: " . $e->getMessage());
}
?>
<?php
